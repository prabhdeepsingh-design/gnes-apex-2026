MASTER PROJECTS ZIP

This archive contains two separate project asset folders:

1. HeritageHub — Our Culture, Our Pride
   Contains the assets from Web wizards assets 1.zip.

2. EVolt — Drive the Electric Future
   Contains the assets from EVolt_Combined_Project_Files(1).zip.

Original filenames and subfolder structure are preserved within each project.
