EVolt Icon Pack — Black and White Variants

Original icons are preserved in the root of EVolt_Icon_Pack.
- icons-black/: all icons recolored solid black
- icons-white/: all icons recolored solid white

Both variants preserve the original PNG dimensions (256 × 256), transparent background,
and antialiased alpha edges. There are 31 icons in each variant folder.
