EVolt Icon Pack
===============
31 individually named transparent PNG icons for the EVolt — Drive the Electric Future website.
- Format: PNG with transparent background
- Canvas: 256 x 256 px
- Colors: dark navy and green
- Designed for local/offline use; no external dependencies.
Use directly in HTML, e.g. <img src="assets/icons/electric-car.png" alt="Electric car">
